export const USER = { name: 'Carlos Herrera', productor: 'Productor Unibán #1042' };

export const PARCELAS = [
  { id: 'p1', nombre: 'La Esperanza', area: 2.4, ciclo: 'Activo', fechaInicio: '2024-01-15', estado: 'Producción' },
  { id: 'p2', nombre: 'El Progreso', area: 1.8, ciclo: 'Activo', fechaInicio: '2024-02-20', estado: 'Producción' },
  { id: 'p3', nombre: 'La Palma', area: 3.1, ciclo: 'Preparación', fechaInicio: '2024-03-01', estado: 'En preparación' },
  { id: 'p4', nombre: 'El Mirador', area: 1.5, ciclo: 'Descanso', fechaInicio: '2023-10-10', estado: 'Descanso' },
  { id: 'p5', nombre: 'Los Almendros', area: 2.0, ciclo: 'Activo', fechaInicio: '2024-01-28', estado: 'Producción' },
];

export const INSUMOS = [
  { id: 'i1', nombre: 'Fertilizante 15-15-15', categoria: 'Fertilizante', cantidad: 120, unidad: 'kg', ubicacion: 'Bodega principal' },
  { id: 'i2', nombre: 'Fungicida Mancozeb', categoria: 'Fungicida', cantidad: 35, unidad: 'L', ubicacion: 'Bodega principal' },
  { id: 'i3', nombre: 'Urea 46%', categoria: 'Fertilizante', cantidad: 80, unidad: 'kg', ubicacion: 'Bodega secundaria' },
  { id: 'i4', nombre: 'Clorpirifos 480 EC', categoria: 'Insecticida', cantidad: 12, unidad: 'L', ubicacion: 'Bodega principal' },
  { id: 'i5', nombre: 'Cal dolomítica', categoria: 'Correctivo', cantidad: 200, unidad: 'kg', ubicacion: 'Depósito campo' },
  { id: 'i6', nombre: 'Sulfato de potasio', categoria: 'Fertilizante', cantidad: 60, unidad: 'kg', ubicacion: 'Bodega principal' },
];

export const MOVIMIENTOS = [
  { id: 'm1', tipo: 'Consumo', insumo: 'Fertilizante 15-15-15', cantidad: 15, unidad: 'kg', fecha: '12 abr', parcela: 'La Esperanza', actividad: 'Fertilización', ubicacion: 'Bodega principal' },
  { id: 'm2', tipo: 'Entrada', insumo: 'Urea 46%', cantidad: 50, unidad: 'kg', fecha: '10 abr', parcela: null, actividad: null, ubicacion: 'Bodega secundaria' },
  { id: 'm3', tipo: 'Consumo', insumo: 'Fungicida Mancozeb', cantidad: 8, unidad: 'L', fecha: '8 abr', parcela: 'El Progreso', actividad: 'Control fitosanitario', ubicacion: 'Bodega principal' },
  { id: 'm4', tipo: 'Salida', insumo: 'Clorpirifos 480 EC', cantidad: 3, unidad: 'L', fecha: '5 abr', parcela: null, actividad: null, ubicacion: 'Bodega principal' },
  { id: 'm5', tipo: 'Pérdida', insumo: 'Cal dolomítica', cantidad: 10, unidad: 'kg', fecha: '2 abr', parcela: null, actividad: null, ubicacion: 'Depósito campo' },
  { id: 'm6', tipo: 'Ajuste', insumo: 'Sulfato de potasio', cantidad: 5, unidad: 'kg', fecha: '1 abr', parcela: null, actividad: null, ubicacion: 'Bodega principal' },
];

export const ACTIVIDADES = [
  { id: 'a1', tipo: 'Fertilización', parcela: 'La Esperanza', fecha: '12 abr 2024', ciclo: 'Ciclo activo' },
  { id: 'a2', tipo: 'Control fitosanitario', parcela: 'El Progreso', fecha: '8 abr 2024', ciclo: 'Ciclo activo' },
  { id: 'a3', tipo: 'Cosecha', parcela: 'Los Almendros', fecha: '5 abr 2024', ciclo: 'Ciclo activo' },
  { id: 'a4', tipo: 'Siembra', parcela: 'La Palma', fecha: '1 abr 2024', ciclo: 'Preparación' },
  { id: 'a5', tipo: 'Aplicación de insumo', parcela: 'La Esperanza', fecha: '28 mar 2024', ciclo: 'Ciclo activo' },
  { id: 'a6', tipo: 'Fertilización', parcela: 'El Mirador', fecha: '20 mar 2024', ciclo: 'Descanso' },
];

export const RECOMENDACIONES = [
  { id: 'r1', parcela: 'La Esperanza', ciclo: 'Ciclo activo', periodo: 'Abr – May 2024', insumo: 'Fertilizante 15-15-15', cantidad: '20 kg', obs: 'Aplicar en las primeras horas del día', alerta: null },
  { id: 'r2', parcela: 'El Progreso', ciclo: 'Ciclo activo', periodo: 'Abr 2024', insumo: 'Fungicida Mancozeb', cantidad: '10 L', obs: 'Verificar humedad antes de aplicar', alerta: 'Riesgo de lluvia próximas 48h' },
  { id: 'r3', parcela: 'Los Almendros', ciclo: 'Ciclo activo', periodo: 'May 2024', insumo: null, cantidad: null, obs: 'Revisar aforamiento antes del próximo ciclo', alerta: null },
];
