import { useState } from 'react';
import { MOVIMIENTOS, INSUMOS } from '../data';
import TopBar from '../components/TopBar';
import { SyncStatus } from '../types';

interface Props {
  syncStatus: SyncStatus;
  onBack: () => void;
}

const TIPOS_FILTRO = ['Todos', 'Entrada', 'Salida', 'Consumo', 'Pérdida', 'Ajuste'];

const tipoStyles: Record<string, { bg: string; text: string; symbol: string }> = {
  Entrada:  { bg: 'bg-[#E8F5E9]', text: 'text-[#2E7D32]', symbol: '+' },
  Consumo:  { bg: 'bg-[#FFF8E1]', text: 'text-[#F9A825]', symbol: '·' },
  Salida:   { bg: 'bg-[#FFF8E1]', text: 'text-[#F9A825]', symbol: '−' },
  Pérdida:  { bg: 'bg-[#FFEBEE]', text: 'text-[#C62828]', symbol: '−' },
  Ajuste:   { bg: 'bg-gray-100',  text: 'text-[#6B7B6C]',  symbol: '±' },
};

export default function HistorialScreen({ syncStatus, onBack }: Props) {
  const [tipoFiltro, setTipoFiltro] = useState('Todos');
  const [insumoFiltro, setInsumoFiltro] = useState('Todos');

  const filtered = MOVIMIENTOS.filter(m => {
    const matchTipo = tipoFiltro === 'Todos' || m.tipo === tipoFiltro;
    const matchInsumo = insumoFiltro === 'Todos' || m.insumo === insumoFiltro;
    return matchTipo && matchInsumo;
  });

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Historial / Trazabilidad" onBack={onBack} syncStatus={syncStatus} />
      <div className="px-4 pt-3 pb-2 flex flex-col gap-2 bg-white border-b border-[#D8E5D9]">
        <div className="flex gap-2 overflow-x-auto">
          {TIPOS_FILTRO.map(t => (
            <button
              key={t} onClick={() => setTipoFiltro(t)}
              className={`flex-shrink-0 text-xs px-3 py-1.5 rounded-full border transition-all ${tipoFiltro === t ? 'bg-[#1B5E20] text-white border-[#1B5E20]' : 'bg-white text-[#6B7B6C] border-[#D8E5D9]'}`}
            >
              {t}
            </button>
          ))}
        </div>
        <select
          value={insumoFiltro} onChange={e => setInsumoFiltro(e.target.value)}
          className="w-full px-3 py-2 rounded-xl border border-[#D8E5D9] bg-[#F4F6F4] text-xs text-[#1C2B1D] focus:outline-none"
        >
          <option value="Todos">Todos los insumos</option>
          {INSUMOS.map(i => <option key={i.id} value={i.nombre}>{i.nombre}</option>)}
        </select>
      </div>

      <div className="flex-1 overflow-y-auto scrollable px-4 py-3 pb-24 flex flex-col gap-2">
        <p className="text-xs text-[#6B7B6C] mb-1">{filtered.length} registros</p>
        {filtered.map(m => {
          const s = tipoStyles[m.tipo] ?? tipoStyles['Ajuste'];
          return (
            <div key={m.id} className="bg-white rounded-xl p-4 shadow-sm border border-[#D8E5D9]">
              <div className="flex items-start gap-3">
                <div className={`w-9 h-9 ${s.bg} rounded-full flex items-center justify-center flex-shrink-0`}>
                  <span className={`text-base font-bold ${s.text}`}>{s.symbol}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${s.bg} ${s.text}`}>{m.tipo}</span>
                    <span className="text-xs text-[#6B7B6C]">{m.fecha}</span>
                  </div>
                  <p className="text-sm font-medium text-[#1C2B1D] mt-1">{m.insumo}</p>
                  <p className="text-xs text-[#6B7B6C]">{m.cantidad} {m.unidad} · {m.ubicacion}</p>
                  {m.parcela && (
                    <p className="text-xs text-[#2E7D32] mt-0.5">📍 {m.parcela}{m.actividad ? ` · ${m.actividad}` : ''}</p>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
