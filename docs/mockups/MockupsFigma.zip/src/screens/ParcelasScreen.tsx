import { PARCELAS } from '../data';
import TopBar from '../components/TopBar';
import { SyncStatus } from '../types';

interface Props {
  syncStatus: SyncStatus;
  onBack: () => void;
  onSelect: (id: string) => void;
}

const estadoColors: Record<string, string> = {
  'Producción': 'bg-[#E8F5E9] text-[#2E7D32]',
  'En preparación': 'bg-[#FFF8E1] text-[#F9A825]',
  'Descanso': 'bg-gray-100 text-[#6B7B6C]',
};

export default function ParcelasScreen({ syncStatus, onBack, onSelect }: Props) {
  return (
    <div className="flex flex-col h-full">
      <TopBar title="Mis Parcelas" onBack={onBack} syncStatus={syncStatus} />
      <div className="flex-1 overflow-y-auto scrollable px-4 py-4 pb-24 flex flex-col gap-3">
        <p className="text-xs text-[#6B7B6C] mb-1">{PARCELAS.length} parcelas registradas</p>
        {PARCELAS.map(p => (
          <button
            key={p.id}
            onClick={() => onSelect(p.id)}
            className="bg-white rounded-2xl p-4 shadow-sm border border-[#D8E5D9] text-left active:scale-[.99] transition-transform w-full"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <h3 className="text-base font-semibold text-[#1C2B1D]">{p.nombre}</h3>
                <p className="text-sm text-[#6B7B6C] mt-0.5">Área: {p.area} ha</p>
                <p className="text-xs text-[#6B7B6C]">Inicio: {p.fechaInicio}</p>
              </div>
              <div className="flex flex-col items-end gap-2 ml-3">
                <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${estadoColors[p.estado] ?? 'bg-gray-100 text-gray-600'}`}>
                  {p.estado}
                </span>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6B7B6C" strokeWidth="2.5"><polyline points="9 18 15 12 9 6" /></svg>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
