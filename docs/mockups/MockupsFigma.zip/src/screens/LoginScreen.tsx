import { useState } from 'react';

interface Props {
  onLogin: () => void;
}

export default function LoginScreen({ onLogin }: Props) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !password) {
      setError('Por favor ingrese sus credenciales.');
      return;
    }
    setError('');
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLogin();
    }, 900);
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F6F4]">
      {/* Green top band */}
      <div className="bg-[#1B5E20] pt-16 pb-12 px-6 flex flex-col items-center">
        {/* Logo mark */}
        <div className="w-20 h-20 bg-white/10 rounded-2xl flex items-center justify-center mb-4 border border-white/20">
          <svg width="44" height="44" viewBox="0 0 48 48" fill="none">
            <ellipse cx="24" cy="28" rx="14" ry="10" fill="#A5D6A7" />
            <path d="M24 28 C18 16, 10 12, 12 8 C18 4, 28 10, 30 18 C32 12, 38 6, 40 10 C42 18, 34 22, 24 28Z" fill="#4CAF50" />
            <path d="M24 28 L24 40" stroke="#2E7D32" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        </div>
        <h1 className="text-white text-2xl font-bold tracking-tight">Unibán Campo</h1>
        <p className="text-white/70 text-sm mt-1">Gestión agrícola de productores</p>
      </div>

      {/* Form card */}
      <div className="flex-1 px-5 -mt-6">
        <div className="bg-white rounded-2xl shadow-md p-6">
          <h2 className="text-[#1C2B1D] text-lg font-semibold mb-5">Iniciar sesión</h2>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label className="block text-xs font-medium text-[#6B7B6C] mb-1.5">Correo electrónico</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="usuario@unibanagro.com"
                className="w-full px-4 py-3 rounded-xl border border-[#D8E5D9] bg-[#F4F6F4] text-[#1C2B1D] text-sm focus:outline-none focus:border-[#2E7D32] focus:ring-2 focus:ring-[#2E7D32]/20 transition"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#6B7B6C] mb-1.5">Contraseña</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3 rounded-xl border border-[#D8E5D9] bg-[#F4F6F4] text-[#1C2B1D] text-sm focus:outline-none focus:border-[#2E7D32] focus:ring-2 focus:ring-[#2E7D32]/20 transition"
              />
            </div>

            {error && (
              <div className="flex items-center gap-2 bg-[#FFEBEE] border border-[#FFCDD2] rounded-xl px-4 py-3 text-sm text-[#C62828]">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" /></svg>
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#1B5E20] text-white font-semibold text-base py-3.5 rounded-xl mt-2 active:scale-[.98] transition-all disabled:opacity-70"
            >
              {loading ? 'Ingresando…' : 'Iniciar sesión'}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-[#6B7B6C] mt-6">
          ¿Problemas para ingresar? Contacte a su asesor Unibán.
        </p>
      </div>
    </div>
  );
}
