import { SyncStatus, Screen } from '../types';
import SyncBadge from '../components/SyncBadge';
import { USER, PARCELAS, INSUMOS, ACTIVIDADES, MOVIMIENTOS } from '../data';

interface Props {
  syncStatus: SyncStatus;
  lastSync: string;
  onNavigate: (s: Screen) => void;
}

function StatCard({ value, label, icon }: { value: string | number; label: string; icon: React.ReactNode }) {
  return (
    <div className="bg-white rounded-2xl p-4 flex flex-col gap-1 shadow-sm border border-[#D8E5D9]">
      <span className="text-[#2E7D32]">{icon}</span>
      <span className="text-2xl font-bold text-[#1C2B1D]">{value}</span>
      <span className="text-xs text-[#6B7B6C]">{label}</span>
    </div>
  );
}

function QuickAction({ label, icon, onClick }: { label: string; icon: React.ReactNode; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1.5 bg-white rounded-2xl py-4 px-2 shadow-sm border border-[#D8E5D9] active:scale-95 transition-transform">
      <span className="w-10 h-10 bg-[#E8F5E9] rounded-full flex items-center justify-center text-[#1B5E20]">{icon}</span>
      <span className="text-xs font-medium text-[#1C2B1D] text-center leading-tight">{label}</span>
    </button>
  );
}

export default function DashboardScreen({ syncStatus, lastSync, onNavigate }: Props) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Buenos días' : hour < 18 ? 'Buenas tardes' : 'Buenas noches';

  return (
    <div className="pb-24 scrollable h-full overflow-y-auto">
      {/* Header */}
      <div className="bg-[#1B5E20] px-5 pt-12 pb-8">
        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-white/70 text-sm">{greeting},</p>
            <h1 className="text-white text-xl font-bold">{USER.name}</h1>
            <p className="text-white/50 text-xs mt-0.5">{USER.productor}</p>
          </div>
          <button onClick={() => onNavigate('sincronizacion')} className="mt-1">
            <SyncBadge status={syncStatus} />
          </button>
        </div>
        <p className="text-white/50 text-xs">Última sync: {lastSync}</p>
      </div>

      <div className="px-4 -mt-4 flex flex-col gap-5">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <StatCard value={PARCELAS.length} label="Parcelas" icon={
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21" /></svg>
          } />
          <StatCard value={INSUMOS.length} label="Insumos" icon={
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z" /></svg>
          } />
          <StatCard value={ACTIVIDADES.length} label="Actividades" icon={
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2" /><polyline points="9 16 11 18 15 14" /></svg>
          } />
        </div>

        {/* Sync state card */}
        {syncStatus !== 'synced' && (
          <div className={`rounded-2xl p-4 flex items-center gap-3 ${syncStatus === 'pending' ? 'bg-[#FFF8E1] border border-[#FFE082]' : syncStatus === 'error' ? 'bg-[#FFEBEE] border border-[#FFCDD2]' : 'bg-gray-50 border border-gray-200'}`}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={syncStatus === 'error' ? '#C62828' : syncStatus === 'pending' ? '#F9A825' : '#9E9E9E'} strokeWidth="2.5"><circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" /></svg>
            <div className="flex-1">
              <p className="text-sm font-medium text-[#1C2B1D]">{syncStatus === 'pending' ? '2 registros pendientes de sync' : syncStatus === 'error' ? 'Error de sincronización' : 'Sin conexión a internet'}</p>
              <p className="text-xs text-[#6B7B6C]">Toca para ver detalles</p>
            </div>
            <button onClick={() => onNavigate('sincronizacion')} className="text-[#1B5E20] font-medium text-sm">Ver</button>
          </div>
        )}

        {/* Quick actions */}
        <div>
          <h2 className="text-sm font-semibold text-[#6B7B6C] mb-3 uppercase tracking-wide">Accesos rápidos</h2>
          <div className="grid grid-cols-4 gap-2">
            <QuickAction label="Parcelas" onClick={() => onNavigate('parcelas')} icon={
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21" /></svg>
            } />
            <QuickAction label="Inventario" onClick={() => onNavigate('inventario')} icon={
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z" /></svg>
            } />
            <QuickAction label="Actividades" onClick={() => onNavigate('actividades')} icon={
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2" /><polyline points="9 16 11 18 15 14" /></svg>
            } />
            <QuickAction label="Historial" onClick={() => onNavigate('historial')} icon={
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="1 4 1 10 7 10" /><path d="M3.51 15a9 9 0 1 0 .49-3.68" /></svg>
            } />
          </div>
        </div>

        {/* Recent activities */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-[#6B7B6C] uppercase tracking-wide">Actividades recientes</h2>
            <button onClick={() => onNavigate('actividades')} className="text-xs text-[#2E7D32] font-medium">Ver todas</button>
          </div>
          <div className="flex flex-col gap-2">
            {ACTIVIDADES.slice(0, 3).map(a => (
              <div key={a.id} className="bg-white rounded-xl p-3.5 flex items-center gap-3 shadow-sm border border-[#D8E5D9]">
                <div className="w-9 h-9 bg-[#E8F5E9] rounded-full flex items-center justify-center flex-shrink-0">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2E7D32" strokeWidth="2.5"><polyline points="9 16 11 18 15 14" /><rect x="3" y="4" width="18" height="18" rx="2" /></svg>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#1C2B1D] truncate">{a.tipo}</p>
                  <p className="text-xs text-[#6B7B6C]">{a.parcela} · {a.fecha}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent inventory */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-[#6B7B6C] uppercase tracking-wide">Movimientos recientes</h2>
            <button onClick={() => onNavigate('historial')} className="text-xs text-[#2E7D32] font-medium">Ver todos</button>
          </div>
          <div className="flex flex-col gap-2">
            {MOVIMIENTOS.slice(0, 3).map(m => {
              const isEntry = m.tipo === 'Entrada' || m.tipo === 'Ajuste';
              const isLoss = m.tipo === 'Pérdida';
              return (
                <div key={m.id} className="bg-white rounded-xl p-3.5 flex items-center gap-3 shadow-sm border border-[#D8E5D9]">
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${isLoss ? 'bg-[#FFEBEE]' : isEntry ? 'bg-[#E8F5E9]' : 'bg-[#FFF8E1]'}`}>
                    <span className={`text-base font-bold ${isLoss ? 'text-[#C62828]' : isEntry ? 'text-[#2E7D32]' : 'text-[#F9A825]'}`}>
                      {isEntry ? '+' : isLoss ? '−' : '·'}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-[#1C2B1D] truncate">{m.insumo}</p>
                    <p className="text-xs text-[#6B7B6C]">{m.tipo} · {m.cantidad} {m.unidad} · {m.fecha}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recommendations */}
        <div className="mb-2">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-[#6B7B6C] uppercase tracking-wide">Recomendaciones</h2>
            <button onClick={() => onNavigate('recomendaciones')} className="text-xs text-[#2E7D32] font-medium">Ver todas</button>
          </div>
          <div className="bg-[#E8F5E9] rounded-2xl p-4 flex items-center gap-3 border border-[#C8E6C9]">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B5E20" strokeWidth="2.5"><circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" /></svg>
            <div>
              <p className="text-sm font-semibold text-[#1B5E20]">3 recomendaciones disponibles</p>
              <p className="text-xs text-[#2E7D32] mt-0.5">Para La Esperanza, El Progreso y Los Almendros</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
