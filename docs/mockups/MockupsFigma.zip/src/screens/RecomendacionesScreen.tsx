import { RECOMENDACIONES } from '../data';
import TopBar from '../components/TopBar';
import { SyncStatus } from '../types';

interface Props {
  syncStatus: SyncStatus;
  onBack: () => void;
}

export default function RecomendacionesScreen({ syncStatus, onBack }: Props) {
  return (
    <div className="flex flex-col h-full">
      <TopBar title="Recomendaciones" onBack={onBack} syncStatus={syncStatus} />
      <div className="flex-1 overflow-y-auto scrollable px-4 py-4 pb-24 flex flex-col gap-3">
        <p className="text-xs text-[#6B7B6C] mb-1">{RECOMENDACIONES.length} recomendaciones disponibles</p>
        {RECOMENDACIONES.map(r => (
          <div key={r.id} className="bg-white rounded-2xl p-4 shadow-sm border border-[#D8E5D9]">
            {r.alerta && (
              <div className="bg-[#FFF8E1] border border-[#FFE082] rounded-xl px-3 py-2 flex items-center gap-2 mb-3">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#F9A825" strokeWidth="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" /><line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" /></svg>
                <p className="text-xs font-medium text-[#5D3A00]">{r.alerta}</p>
              </div>
            )}
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="text-sm font-semibold text-[#1C2B1D]">{r.parcela}</p>
                <p className="text-xs text-[#6B7B6C]">{r.ciclo}</p>
              </div>
              <span className="text-xs bg-[#E8F5E9] text-[#2E7D32] px-2.5 py-1 rounded-full font-medium">{r.periodo}</span>
            </div>
            {r.insumo && (
              <div className="bg-[#F4F6F4] rounded-xl px-3 py-2.5 mb-3 flex items-center justify-between">
                <div>
                  <p className="text-xs text-[#6B7B6C]">Insumo recomendado</p>
                  <p className="text-sm font-medium text-[#1C2B1D]">{r.insumo}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-[#6B7B6C]">Cantidad</p>
                  <p className="text-sm font-bold text-[#1B5E20]">{r.cantidad}</p>
                </div>
              </div>
            )}
            <p className="text-xs text-[#6B7B6C] leading-relaxed">{r.obs}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
