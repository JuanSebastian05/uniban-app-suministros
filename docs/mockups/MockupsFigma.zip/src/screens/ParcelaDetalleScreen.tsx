import { PARCELAS, ACTIVIDADES, MOVIMIENTOS } from '../data';
import TopBar from '../components/TopBar';
import { Screen, SyncStatus } from '../types';

interface Props {
  parcelaId: string;
  syncStatus: SyncStatus;
  onBack: () => void;
  onNavigate: (s: Screen) => void;
}

export default function ParcelaDetalleScreen({ parcelaId, syncStatus, onBack, onNavigate }: Props) {
  const parcela = PARCELAS.find(p => p.id === parcelaId) ?? PARCELAS[0];
  const actividades = ACTIVIDADES.filter(a => a.parcela === parcela.nombre);
  const consumos = MOVIMIENTOS.filter(m => m.parcela === parcela.nombre);

  return (
    <div className="flex flex-col h-full">
      <TopBar title={parcela.nombre} onBack={onBack} syncStatus={syncStatus} />
      <div className="flex-1 overflow-y-auto scrollable pb-24">
        {/* Hero info */}
        <div className="bg-[#1B5E20] px-5 py-5">
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Área', value: `${parcela.area} ha` },
              { label: 'Estado', value: parcela.estado },
              { label: 'Ciclo', value: parcela.ciclo },
              { label: 'Inicio', value: parcela.fechaInicio },
            ].map(item => (
              <div key={item.label} className="bg-white/10 rounded-xl px-3 py-2.5">
                <p className="text-white/60 text-xs">{item.label}</p>
                <p className="text-white font-semibold text-sm mt-0.5">{item.value}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="px-4 py-4 flex flex-col gap-5">
          {/* Aforamiento */}
          <section>
            <h2 className="text-sm font-semibold text-[#6B7B6C] uppercase tracking-wide mb-3">Aforamiento</h2>
            <div className="bg-[#E8F5E9] rounded-2xl p-4 border border-[#C8E6C9]">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-[#1B5E20]">Aforamiento reciente</p>
                  <p className="text-xs text-[#2E7D32] mt-0.5">Fecha: 5 abr 2024 · 320 plantas/ha</p>
                </div>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2E7D32" strokeWidth="2.5"><polyline points="9 18 15 12 9 6" /></svg>
              </div>
            </div>
          </section>

          {/* Actividades */}
          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-[#6B7B6C] uppercase tracking-wide">Actividades</h2>
              <button onClick={() => onNavigate('actividades')} className="text-xs text-[#2E7D32] font-medium">Ver todas</button>
            </div>
            {actividades.length > 0 ? (
              <div className="flex flex-col gap-2">
                {actividades.map(a => (
                  <div key={a.id} className="bg-white rounded-xl p-3.5 shadow-sm border border-[#D8E5D9] flex items-center gap-3">
                    <div className="w-8 h-8 bg-[#E8F5E9] rounded-full flex items-center justify-center flex-shrink-0">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#2E7D32" strokeWidth="2.5"><polyline points="9 16 11 18 15 14" /></svg>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#1C2B1D]">{a.tipo}</p>
                      <p className="text-xs text-[#6B7B6C]">{a.fecha}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-[#6B7B6C] bg-[#F4F6F4] rounded-xl p-4 text-center">Sin actividades registradas</p>
            )}
            <button
              onClick={() => onNavigate('registrar-actividad')}
              className="w-full mt-3 bg-[#1B5E20] text-white font-semibold py-3 rounded-xl active:scale-[.98] transition-transform"
            >
              + Registrar actividad
            </button>
          </section>

          {/* Consumos vinculados */}
          {consumos.length > 0 && (
            <section>
              <h2 className="text-sm font-semibold text-[#6B7B6C] uppercase tracking-wide mb-3">Insumos consumidos</h2>
              <div className="flex flex-col gap-2">
                {consumos.map(m => (
                  <div key={m.id} className="bg-white rounded-xl p-3.5 shadow-sm border border-[#D8E5D9] flex items-center gap-3">
                    <div className="w-8 h-8 bg-[#FFF8E1] rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-[#F9A825]">·</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#1C2B1D]">{m.insumo}</p>
                      <p className="text-xs text-[#6B7B6C]">{m.tipo} · {m.cantidad} {m.unidad} · {m.fecha}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Recomendaciones */}
          <section>
            <h2 className="text-sm font-semibold text-[#6B7B6C] uppercase tracking-wide mb-3">Recomendaciones</h2>
            <div className="bg-[#FFF8E1] rounded-2xl p-4 border border-[#FFE082] flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-[#5D3A00]">1 recomendación disponible</p>
                <p className="text-xs text-[#6B7B6C] mt-0.5">Fertilización · Abr–May 2024</p>
              </div>
              <button onClick={() => onNavigate('recomendaciones')} className="text-sm font-medium text-[#F9A825]">Ver</button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
