import { SyncStatus } from '../types';
import TopBar from '../components/TopBar';

interface Props {
  syncStatus: SyncStatus;
  lastSync: string;
  pendingCount: number;
  errorCount: number;
  onBack: () => void;
  onRetry: () => void;
}

const statusConfig: Record<SyncStatus, { label: string; desc: string; bg: string; icon: string; color: string }> = {
  synced:  { label: 'Sincronizado',         desc: 'Todos los datos están actualizados.',         bg: 'bg-[#E8F5E9] border-[#C8E6C9]', icon: '✓', color: 'text-[#1B5E20]' },
  offline: { label: 'Sin conexión',          desc: 'No hay acceso a internet. Modo campo activo.', bg: 'bg-gray-100 border-gray-200',     icon: '○', color: 'text-[#6B7B6C]' },
  pending: { label: 'Pendiente de sync',     desc: 'Hay registros listos para sincronizar.',       bg: 'bg-[#FFF8E1] border-[#FFE082]',   icon: '⏳', color: 'text-[#5D3A00]' },
  error:   { label: 'Error de sincronización', desc: 'No fue posible sincronizar. Verifique conexión.', bg: 'bg-[#FFEBEE] border-[#FFCDD2]', icon: '!', color: 'text-[#C62828]' },
};

export default function SincronizacionScreen({ syncStatus, lastSync, pendingCount, errorCount, onBack, onRetry }: Props) {
  const cfg = statusConfig[syncStatus];

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Estado de sincronización" onBack={onBack} />
      <div className="flex-1 overflow-y-auto scrollable px-4 py-6 flex flex-col gap-4">
        {/* Main status */}
        <div className={`rounded-2xl p-5 border ${cfg.bg} flex flex-col items-center gap-2 text-center`}>
          <span className={`text-4xl ${cfg.color}`}>{cfg.icon}</span>
          <p className={`text-xl font-bold ${cfg.color}`}>{cfg.label}</p>
          <p className="text-sm text-[#6B7B6C]">{cfg.desc}</p>
        </div>

        {/* Detail cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#D8E5D9]">
            <p className="text-xs text-[#6B7B6C]">Última sincronización</p>
            <p className="text-sm font-semibold text-[#1C2B1D] mt-1">{lastSync}</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#D8E5D9]">
            <p className="text-xs text-[#6B7B6C]">Estado de red</p>
            <p className={`text-sm font-semibold mt-1 ${syncStatus === 'offline' ? 'text-[#6B7B6C]' : 'text-[#1B5E20]'}`}>
              {syncStatus === 'offline' ? 'Sin conexión' : 'Conectado'}
            </p>
          </div>
          <div className={`rounded-2xl p-4 shadow-sm border ${pendingCount > 0 ? 'bg-[#FFF8E1] border-[#FFE082]' : 'bg-white border-[#D8E5D9]'}`}>
            <p className="text-xs text-[#6B7B6C]">Registros pendientes</p>
            <p className={`text-2xl font-bold mt-1 ${pendingCount > 0 ? 'text-[#F9A825]' : 'text-[#1B5E20]'}`}>{pendingCount}</p>
          </div>
          <div className={`rounded-2xl p-4 shadow-sm border ${errorCount > 0 ? 'bg-[#FFEBEE] border-[#FFCDD2]' : 'bg-white border-[#D8E5D9]'}`}>
            <p className="text-xs text-[#6B7B6C]">Errores</p>
            <p className={`text-2xl font-bold mt-1 ${errorCount > 0 ? 'text-[#C62828]' : 'text-[#1B5E20]'}`}>{errorCount}</p>
          </div>
        </div>

        {/* Offline note */}
        {syncStatus === 'offline' && (
          <div className="bg-[#E8F5E9] rounded-2xl p-4 border border-[#C8E6C9]">
            <p className="text-sm font-semibold text-[#1B5E20] mb-1">Modo campo activo</p>
            <p className="text-xs text-[#2E7D32]">Puede seguir registrando actividades e inventario sin conexión. Los datos se sincronizarán automáticamente cuando vuelva la conexión.</p>
          </div>
        )}

        <button
          onClick={onRetry}
          className={`w-full font-semibold py-3.5 rounded-xl transition-all active:scale-[.98] ${syncStatus === 'offline' ? 'bg-gray-200 text-[#6B7B6C] cursor-not-allowed' : 'bg-[#1B5E20] text-white'}`}
          disabled={syncStatus === 'offline'}
        >
          Reintentar sincronización
        </button>
      </div>
    </div>
  );
}
