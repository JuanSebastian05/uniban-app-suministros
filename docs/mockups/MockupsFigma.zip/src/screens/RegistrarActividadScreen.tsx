import { useState } from 'react';
import TopBar from '../components/TopBar';
import { SyncStatus } from '../types';
import { PARCELAS } from '../data';

interface Props {
  syncStatus: SyncStatus;
  onBack: () => void;
  onSaved: () => void;
}

const TIPOS = ['Fertilización', 'Siembra', 'Cosecha', 'Aplicación de insumo', 'Control fitosanitario', 'Otra actividad'];

export default function RegistrarActividadScreen({ syncStatus, onBack, onSaved }: Props) {
  const [tipo, setTipo] = useState('');
  const [parcela, setParcela] = useState('');
  const [fecha, setFecha] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [saved, setSaved] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaved(true);
    setTimeout(onSaved, 1400);
  }

  if (saved) {
    return (
      <div className="flex flex-col h-full items-center justify-center gap-4 px-6">
        <div className="w-20 h-20 bg-[#E8F5E9] rounded-full flex items-center justify-center">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#1B5E20" strokeWidth="2.5"><polyline points="20 6 9 17 4 12" /></svg>
        </div>
        <p className="text-lg font-semibold text-[#1C2B1D]">Actividad guardada</p>
        <p className="text-sm text-[#6B7B6C] text-center">El registro quedó pendiente de sincronización.</p>
        <span className="bg-[#FFF8E1] border border-[#FFE082] text-[#5D3A00] text-sm font-medium px-4 py-2 rounded-full">⏳ Pendiente de sync</span>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Registrar actividad" onBack={onBack} syncStatus={syncStatus} />
      <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto scrollable px-4 py-4 pb-28 flex flex-col gap-4">
        <div>
          <label className="block text-xs font-medium text-[#6B7B6C] mb-2">Tipo de actividad</label>
          <div className="grid grid-cols-2 gap-2">
            {TIPOS.map(t => (
              <button
                key={t} type="button"
                onClick={() => setTipo(t)}
                className={`text-sm py-2.5 px-3 rounded-xl border text-left transition-all ${tipo === t ? 'border-[#1B5E20] bg-[#E8F5E9] text-[#1B5E20] font-medium' : 'border-[#D8E5D9] bg-white text-[#1C2B1D]'}`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-[#6B7B6C] mb-1.5">Parcela</label>
          <select
            value={parcela} onChange={e => setParcela(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-[#D8E5D9] bg-white text-[#1C2B1D] text-sm focus:outline-none focus:border-[#2E7D32]"
          >
            <option value="">Seleccionar parcela</option>
            {PARCELAS.map(p => <option key={p.id} value={p.nombre}>{p.nombre}</option>)}
          </select>
        </div>

        <div>
          <label className="block text-xs font-medium text-[#6B7B6C] mb-1.5">Ciclo productivo</label>
          <select className="w-full px-4 py-3 rounded-xl border border-[#D8E5D9] bg-white text-[#1C2B1D] text-sm focus:outline-none focus:border-[#2E7D32]">
            <option>Ciclo activo</option>
            <option>Preparación</option>
            <option>Descanso</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-medium text-[#6B7B6C] mb-1.5">Fecha</label>
          <input
            type="date" value={fecha} onChange={e => setFecha(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-[#D8E5D9] bg-white text-[#1C2B1D] text-sm focus:outline-none focus:border-[#2E7D32]"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-[#6B7B6C] mb-1.5">Descripción</label>
          <textarea
            rows={3}
            value={descripcion}
            onChange={e => setDescripcion(e.target.value)}
            placeholder="Observaciones o detalles de la actividad…"
            className="w-full px-4 py-3 rounded-xl border border-[#D8E5D9] bg-white text-[#1C2B1D] text-sm focus:outline-none focus:border-[#2E7D32] resize-none"
          />
        </div>
      </form>

      <div className="fixed bottom-0 left-0 right-0 px-4 pb-6 pt-3 bg-[#F4F6F4] border-t border-[#D8E5D9]">
        <button
          onClick={handleSubmit as unknown as React.MouseEventHandler}
          className="w-full bg-[#1B5E20] text-white font-semibold py-3.5 rounded-xl active:scale-[.98] transition-transform"
        >
          Guardar actividad
        </button>
      </div>
    </div>
  );
}
