import { ACTIVIDADES } from '../data';
import TopBar from '../components/TopBar';
import { SyncStatus, Screen } from '../types';

interface Props {
  syncStatus: SyncStatus;
  onBack: () => void;
  onNavigate: (s: Screen) => void;
}

const tipoIcon: Record<string, string> = {
  'Fertilización': '🌿',
  'Siembra': '🌱',
  'Cosecha': '🌾',
  'Aplicación de insumo': '💧',
  'Control fitosanitario': '🛡️',
  'Otra actividad': '📋',
};

export default function ActividadesScreen({ syncStatus, onBack, onNavigate }: Props) {
  return (
    <div className="flex flex-col h-full">
      <TopBar title="Actividades" onBack={onBack} syncStatus={syncStatus} />
      <div className="flex-1 overflow-y-auto scrollable px-4 py-4 pb-28 flex flex-col gap-3">
        <p className="text-xs text-[#6B7B6C] mb-1">{ACTIVIDADES.length} actividades registradas</p>
        {ACTIVIDADES.map(a => (
          <div key={a.id} className="bg-white rounded-2xl p-4 shadow-sm border border-[#D8E5D9]">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-[#E8F5E9] rounded-full flex items-center justify-center text-base flex-shrink-0">
                {tipoIcon[a.tipo] ?? '📋'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-[#1C2B1D]">{a.tipo}</p>
                <p className="text-xs text-[#6B7B6C] mt-0.5">{a.parcela}</p>
                <div className="flex items-center gap-2 mt-1.5">
                  <span className="text-xs bg-[#F4F6F4] px-2 py-0.5 rounded-full text-[#6B7B6C]">{a.fecha}</span>
                  <span className="text-xs bg-[#E8F5E9] px-2 py-0.5 rounded-full text-[#2E7D32]">{a.ciclo}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="fixed bottom-16 left-0 right-0 px-4 pb-3">
        <button
          onClick={() => onNavigate('registrar-actividad')}
          className="w-full bg-[#1B5E20] text-white font-semibold py-3.5 rounded-xl shadow-lg active:scale-[.98] transition-transform"
        >
          + Registrar actividad
        </button>
      </div>
    </div>
  );
}
