import { useState } from 'react';
import TopBar from '../components/TopBar';
import { SyncStatus } from '../types';
import { INSUMOS, ACTIVIDADES } from '../data';

interface Props {
  syncStatus: SyncStatus;
  onBack: () => void;
  onSaved: () => void;
}

const TIPOS = ['Entrada', 'Salida', 'Consumo', 'Pérdida', 'Ajuste'];

const tipoStyle: Record<string, { active: string; bg: string }> = {
  Entrada:  { active: 'border-[#2E7D32] bg-[#E8F5E9] text-[#1B5E20]', bg: '' },
  Salida:   { active: 'border-[#F9A825] bg-[#FFF8E1] text-[#5D3A00]', bg: '' },
  Consumo:  { active: 'border-[#F9A825] bg-[#FFF8E1] text-[#5D3A00]', bg: '' },
  Pérdida:  { active: 'border-[#C62828] bg-[#FFEBEE] text-[#C62828]', bg: '' },
  Ajuste:   { active: 'border-[#6B7B6C] bg-gray-100 text-[#6B7B6C]', bg: '' },
};

export default function RegistrarMovimientoScreen({ syncStatus, onBack, onSaved }: Props) {
  const [insumo, setInsumo] = useState('');
  const [tipo, setTipo] = useState('');
  const [cantidad, setCantidad] = useState('');
  const [fecha, setFecha] = useState('');
  const [actividad, setActividad] = useState('');
  const [obs, setObs] = useState('');
  const [saved, setSaved] = useState(false);
  const [savedStatus, setSavedStatus] = useState<'synced' | 'pending'>('pending');

  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaved(true);
    setSavedStatus(syncStatus === 'synced' ? 'synced' : 'pending');
    setTimeout(onSaved, 1600);
  }

  const selectedInsumo = INSUMOS.find(i => i.id === insumo);

  if (saved) {
    const isSynced = savedStatus === 'synced';
    return (
      <div className="flex flex-col h-full items-center justify-center gap-4 px-6 text-center">
        <div className={`w-20 h-20 rounded-full flex items-center justify-center ${isSynced ? 'bg-[#E8F5E9]' : 'bg-[#FFF8E1]'}`}>
          {isSynced
            ? <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#1B5E20" strokeWidth="2.5"><polyline points="20 6 9 17 4 12" /></svg>
            : <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#F9A825" strokeWidth="2.5"><polyline points="1 4 1 10 7 10" /><path d="M3.51 15a9 9 0 1 0 .49-3.68" /></svg>
          }
        </div>
        <p className="text-lg font-semibold text-[#1C2B1D]">Movimiento guardado</p>
        <span className={`text-sm font-medium px-4 py-2 rounded-full border ${isSynced ? 'bg-[#E8F5E9] border-[#C8E6C9] text-[#2E7D32]' : 'bg-[#FFF8E1] border-[#FFE082] text-[#5D3A00]'}`}>
          {isSynced ? '✓ Sincronizado' : '⏳ Pendiente de sincronización'}
        </span>
        {selectedInsumo && (
          <div className="bg-white rounded-2xl p-4 w-full border border-[#D8E5D9] shadow-sm">
            <p className="text-xs text-[#6B7B6C]">Insumo actualizado</p>
            <p className="text-base font-semibold text-[#1C2B1D] mt-1">{selectedInsumo.nombre}</p>
            <p className="text-sm text-[#2E7D32] font-medium">{tipo} · {cantidad} {selectedInsumo.unidad}</p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Registrar movimiento" onBack={onBack} syncStatus={syncStatus} />
      <form onSubmit={handleSave} className="flex-1 overflow-y-auto scrollable px-4 py-4 pb-32 flex flex-col gap-4">
        {/* Insumo */}
        <div>
          <label className="block text-xs font-medium text-[#6B7B6C] mb-1.5">Insumo</label>
          <select
            value={insumo} onChange={e => setInsumo(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-[#D8E5D9] bg-white text-[#1C2B1D] text-sm focus:outline-none focus:border-[#2E7D32]"
          >
            <option value="">Seleccionar insumo</option>
            {INSUMOS.map(i => <option key={i.id} value={i.id}>{i.nombre}</option>)}
          </select>
          {selectedInsumo && (
            <p className="text-xs text-[#6B7B6C] mt-1.5 ml-1">Stock actual: <strong className="text-[#1B5E20]">{selectedInsumo.cantidad} {selectedInsumo.unidad}</strong></p>
          )}
        </div>

        {/* Tipo */}
        <div>
          <label className="block text-xs font-medium text-[#6B7B6C] mb-2">Tipo de movimiento</label>
          <div className="flex flex-wrap gap-2">
            {TIPOS.map(t => {
              const s = tipoStyle[t];
              return (
                <button
                  key={t} type="button"
                  onClick={() => setTipo(t)}
                  className={`text-sm px-4 py-2 rounded-full border-2 transition-all font-medium ${tipo === t ? s.active : 'border-[#D8E5D9] bg-white text-[#6B7B6C]'}`}
                >
                  {t}
                </button>
              );
            })}
          </div>
        </div>

        {/* Cantidad */}
        <div>
          <label className="block text-xs font-medium text-[#6B7B6C] mb-1.5">Cantidad</label>
          <div className="flex gap-2">
            <input
              type="number" value={cantidad} onChange={e => setCantidad(e.target.value)}
              placeholder="0"
              className="flex-1 px-4 py-3 rounded-xl border border-[#D8E5D9] bg-white text-[#1C2B1D] text-sm focus:outline-none focus:border-[#2E7D32]"
            />
            <div className="px-4 py-3 rounded-xl border border-[#D8E5D9] bg-[#F4F6F4] text-[#6B7B6C] text-sm min-w-[60px] flex items-center justify-center font-mono">
              {selectedInsumo?.unidad ?? 'ud.'}
            </div>
          </div>
        </div>

        {/* Fecha */}
        <div>
          <label className="block text-xs font-medium text-[#6B7B6C] mb-1.5">Fecha</label>
          <input
            type="date" value={fecha} onChange={e => setFecha(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-[#D8E5D9] bg-white text-[#1C2B1D] text-sm focus:outline-none focus:border-[#2E7D32]"
          />
        </div>

        {/* Actividad (required for Consumo) */}
        <div>
          <label className="block text-xs font-medium text-[#6B7B6C] mb-1.5">
            Actividad asociada
            {tipo === 'Consumo' && <span className="text-[#C62828] ml-1">*</span>}
            {tipo !== 'Consumo' && <span className="text-[#6B7B6C] ml-1 font-normal">(opcional)</span>}
          </label>
          <select
            value={actividad} onChange={e => setActividad(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-[#D8E5D9] bg-white text-[#1C2B1D] text-sm focus:outline-none focus:border-[#2E7D32]"
          >
            <option value="">Sin actividad asociada</option>
            {ACTIVIDADES.map(a => (
              <option key={a.id} value={a.id}>{a.tipo} · {a.parcela} · {a.fecha}</option>
            ))}
          </select>
          {actividad && (() => {
            const act = ACTIVIDADES.find(a => a.id === actividad);
            return act ? (
              <div className="mt-2 bg-[#E8F5E9] rounded-xl px-3 py-2.5 border border-[#C8E6C9]">
                <p className="text-xs font-medium text-[#1B5E20]">{act.tipo}</p>
                <p className="text-xs text-[#6B7B6C]">{act.parcela} · {act.ciclo}</p>
              </div>
            ) : null;
          })()}
        </div>

        {/* Observación */}
        <div>
          <label className="block text-xs font-medium text-[#6B7B6C] mb-1.5">Observación</label>
          <textarea
            rows={2} value={obs} onChange={e => setObs(e.target.value)}
            placeholder="Observaciones adicionales…"
            className="w-full px-4 py-3 rounded-xl border border-[#D8E5D9] bg-white text-[#1C2B1D] text-sm focus:outline-none focus:border-[#2E7D32] resize-none"
          />
        </div>
      </form>

      <div className="fixed bottom-0 left-0 right-0 px-4 pb-6 pt-3 bg-[#F4F6F4] border-t border-[#D8E5D9]">
        <button
          onClick={handleSave as unknown as React.MouseEventHandler}
          className="w-full bg-[#1B5E20] text-white font-semibold py-3.5 rounded-xl active:scale-[.98] transition-transform"
        >
          Guardar movimiento
        </button>
      </div>
    </div>
  );
}
