import { useState } from 'react';
import { INSUMOS } from '../data';
import TopBar from '../components/TopBar';
import { SyncStatus, Screen } from '../types';

interface Props {
  syncStatus: SyncStatus;
  onBack: () => void;
  onSelect: (id: string) => void;
  onNavigate: (s: Screen) => void;
}

const CATEGORIAS = ['Todas', 'Fertilizante', 'Fungicida', 'Insecticida', 'Correctivo'];
const UBICACIONES = ['Todas', 'Bodega principal', 'Bodega secundaria', 'Depósito campo'];

export default function InventarioScreen({ syncStatus, onBack, onSelect, onNavigate }: Props) {
  const [search, setSearch] = useState('');
  const [catFiltro, setCatFiltro] = useState('Todas');
  const [ubiFiltro, setUbiFiltro] = useState('Todas');

  const filtered = INSUMOS.filter(i => {
    const matchSearch = i.nombre.toLowerCase().includes(search.toLowerCase());
    const matchCat = catFiltro === 'Todas' || i.categoria === catFiltro;
    const matchUbi = ubiFiltro === 'Todas' || i.ubicacion === ubiFiltro;
    return matchSearch && matchCat && matchUbi;
  });

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Inventario" onBack={onBack} syncStatus={syncStatus} />
      <div className="px-4 pt-4 pb-2 flex flex-col gap-3 bg-white border-b border-[#D8E5D9]">
        {/* Search */}
        <div className="relative">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B7B6C]" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
          <input
            type="text" value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Buscar insumo…"
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#D8E5D9] bg-[#F4F6F4] text-sm text-[#1C2B1D] focus:outline-none focus:border-[#2E7D32]"
          />
        </div>
        {/* Category filter */}
        <div className="flex gap-2 overflow-x-auto">
          {CATEGORIAS.map(c => (
            <button
              key={c} onClick={() => setCatFiltro(c)}
              className={`flex-shrink-0 text-xs px-3 py-1.5 rounded-full border transition-all ${catFiltro === c ? 'bg-[#1B5E20] text-white border-[#1B5E20]' : 'bg-white text-[#6B7B6C] border-[#D8E5D9]'}`}
            >
              {c}
            </button>
          ))}
        </div>
        {/* Location filter */}
        <div className="flex gap-2 overflow-x-auto">
          {UBICACIONES.map(u => (
            <button
              key={u} onClick={() => setUbiFiltro(u)}
              className={`flex-shrink-0 text-xs px-3 py-1.5 rounded-full border transition-all ${ubiFiltro === u ? 'bg-[#E8F5E9] text-[#1B5E20] border-[#2E7D32]' : 'bg-white text-[#6B7B6C] border-[#D8E5D9]'}`}
            >
              {u}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scrollable px-4 py-3 pb-28 flex flex-col gap-3">
        <p className="text-xs text-[#6B7B6C]">{filtered.length} insumos</p>
        {filtered.map(i => (
          <button
            key={i.id}
            onClick={() => onSelect(i.id)}
            className="bg-white rounded-2xl p-4 shadow-sm border border-[#D8E5D9] text-left active:scale-[.99] transition-transform w-full"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-[#1C2B1D]">{i.nombre}</p>
                <p className="text-xs text-[#6B7B6C] mt-0.5">{i.categoria}</p>
                <p className="text-xs text-[#6B7B6C]">{i.ubicacion}</p>
              </div>
              <div className="flex flex-col items-end gap-1 ml-3 flex-shrink-0">
                <span className="text-base font-bold text-[#1B5E20]">{i.cantidad} {i.unidad}</span>
                <span className="text-xs text-[#6B7B6C]">disponibles</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#6B7B6C" strokeWidth="2.5"><polyline points="9 18 15 12 9 6" /></svg>
              </div>
            </div>
          </button>
        ))}
      </div>

      <div className="fixed bottom-16 left-0 right-0 px-4 pb-3">
        <button
          onClick={() => onNavigate('registrar-movimiento')}
          className="w-full bg-[#1B5E20] text-white font-semibold py-3.5 rounded-xl shadow-lg active:scale-[.98] transition-transform"
        >
          + Registrar movimiento
        </button>
      </div>
    </div>
  );
}
