import { INSUMOS, MOVIMIENTOS } from '../data';
import TopBar from '../components/TopBar';
import { Screen, SyncStatus } from '../types';

interface Props {
  insumoId: string;
  syncStatus: SyncStatus;
  onBack: () => void;
  onNavigate: (s: Screen) => void;
}

const tipoStyles: Record<string, { bg: string; text: string; symbol: string }> = {
  Entrada:  { bg: 'bg-[#E8F5E9]', text: 'text-[#2E7D32]', symbol: '+' },
  Consumo:  { bg: 'bg-[#FFF8E1]', text: 'text-[#F9A825]', symbol: '·' },
  Salida:   { bg: 'bg-[#FFF8E1]', text: 'text-[#F9A825]', symbol: '−' },
  Pérdida:  { bg: 'bg-[#FFEBEE]', text: 'text-[#C62828]', symbol: '−' },
  Ajuste:   { bg: 'bg-gray-100',  text: 'text-[#6B7B6C]',  symbol: '±' },
};

export default function InsumoDetalleScreen({ insumoId, syncStatus, onBack, onNavigate }: Props) {
  const insumo = INSUMOS.find(i => i.id === insumoId) ?? INSUMOS[0];
  const movs = MOVIMIENTOS.filter(m => m.insumo === insumo.nombre);

  return (
    <div className="flex flex-col h-full">
      <TopBar title={insumo.nombre} onBack={onBack} syncStatus={syncStatus} />
      <div className="flex-1 overflow-y-auto scrollable pb-28">
        {/* Hero */}
        <div className="bg-[#1B5E20] px-5 py-5">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Categoría', value: insumo.categoria },
              { label: 'Unidad', value: insumo.unidad },
              { label: 'Ubicación', value: insumo.ubicacion },
              { label: 'Disponible', value: `${insumo.cantidad} ${insumo.unidad}` },
            ].map(item => (
              <div key={item.label} className="bg-white/10 rounded-xl px-3 py-2.5">
                <p className="text-white/60 text-xs">{item.label}</p>
                <p className="text-white font-semibold text-sm mt-0.5">{item.value}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 bg-white/20 rounded-xl px-4 py-3 flex items-center justify-between">
            <p className="text-white/80 text-sm">Stock actual</p>
            <p className="text-white text-2xl font-bold">{insumo.cantidad} <span className="text-base font-medium opacity-70">{insumo.unidad}</span></p>
          </div>
        </div>

        <div className="px-4 py-4 flex flex-col gap-4">
          {/* Movements */}
          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-[#6B7B6C] uppercase tracking-wide">Movimientos recientes</h2>
              <button onClick={() => onNavigate('historial')} className="text-xs text-[#2E7D32] font-medium">Ver historial</button>
            </div>
            {movs.length > 0 ? (
              <div className="flex flex-col gap-2">
                {movs.map(m => {
                  const s = tipoStyles[m.tipo] ?? tipoStyles['Ajuste'];
                  return (
                    <div key={m.id} className="bg-white rounded-xl p-3.5 shadow-sm border border-[#D8E5D9] flex items-center gap-3">
                      <div className={`w-9 h-9 ${s.bg} rounded-full flex items-center justify-center flex-shrink-0`}>
                        <span className={`text-base font-bold ${s.text}`}>{s.symbol}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium text-[#1C2B1D]">{m.tipo}</p>
                          <span className="text-xs text-[#6B7B6C]">{m.fecha}</span>
                        </div>
                        <p className="text-xs text-[#6B7B6C]">{m.cantidad} {m.unidad}{m.parcela ? ` · ${m.parcela}` : ''}</p>
                        {m.actividad && <p className="text-xs text-[#2E7D32] mt-0.5">Actividad: {m.actividad}</p>}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-[#6B7B6C] bg-[#F4F6F4] rounded-xl p-4 text-center">Sin movimientos registrados</p>
            )}
          </section>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 px-4 pb-6 pt-3 bg-[#F4F6F4] border-t border-[#D8E5D9] flex gap-3">
        <button
          onClick={() => onNavigate('historial')}
          className="flex-1 bg-white text-[#1B5E20] font-semibold py-3 rounded-xl border border-[#2E7D32] active:scale-[.98] transition-transform text-sm"
        >
          Ver historial completo
        </button>
        <button
          onClick={() => onNavigate('registrar-movimiento')}
          className="flex-1 bg-[#1B5E20] text-white font-semibold py-3 rounded-xl active:scale-[.98] transition-transform text-sm"
        >
          Registrar movimiento
        </button>
      </div>
    </div>
  );
}
