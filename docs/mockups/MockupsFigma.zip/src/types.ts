export type SyncStatus = 'synced' | 'offline' | 'pending' | 'error';

export type Screen =
  | 'login'
  | 'dashboard'
  | 'parcelas'
  | 'parcela-detalle'
  | 'actividades'
  | 'registrar-actividad'
  | 'inventario'
  | 'insumo-detalle'
  | 'registrar-movimiento'
  | 'historial'
  | 'recomendaciones'
  | 'sincronizacion';

export type NavTab = 'inicio' | 'parcelas' | 'inventario' | 'actividades';

export interface NavState {
  screen: Screen;
  params?: Record<string, unknown>;
}
