import { SyncStatus } from '../types';
import SyncBadge from './SyncBadge';

interface Props {
  title: string;
  onBack?: () => void;
  syncStatus?: SyncStatus;
  action?: React.ReactNode;
}

export default function TopBar({ title, onBack, syncStatus, action }: Props) {
  return (
    <header className="sticky top-0 z-20 bg-[#1B5E20] text-white px-4 py-3 flex items-center gap-3 shadow-md">
      {onBack && (
        <button onClick={onBack} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors -ml-1">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 12H5M12 5l-7 7 7 7" />
          </svg>
        </button>
      )}
      <h1 className="flex-1 text-lg font-semibold tracking-tight truncate">{title}</h1>
      {syncStatus && <SyncBadge status={syncStatus} />}
      {action}
    </header>
  );
}
