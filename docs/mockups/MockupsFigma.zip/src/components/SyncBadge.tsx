import { SyncStatus } from '../types';

const configs: Record<SyncStatus, { label: string; bg: string; dot: string }> = {
  synced:  { label: 'Sincronizado',  bg: 'bg-[#E8F5E9]', dot: 'bg-[#2E7D32]' },
  offline: { label: 'Sin conexión',  bg: 'bg-gray-100',   dot: 'bg-gray-400' },
  pending: { label: '2 pendientes',  bg: 'bg-[#FFF8E1]',  dot: 'bg-[#F9A825]' },
  error:   { label: 'Error de sync', bg: 'bg-[#FFEBEE]',  dot: 'bg-[#C62828]' },
};

export default function SyncBadge({ status }: { status: SyncStatus }) {
  const c = configs[status];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${c.bg} text-[#1C2B1D]`}>
      <span className={`w-2 h-2 rounded-full ${c.dot}`} />
      {c.label}
    </span>
  );
}
