import { useState } from 'react';
import { NavTab, Screen, SyncStatus } from './types';
import BottomNav from './components/BottomNav';
import LoginScreen from './screens/LoginScreen';
import DashboardScreen from './screens/DashboardScreen';
import ParcelasScreen from './screens/ParcelasScreen';
import ParcelaDetalleScreen from './screens/ParcelaDetalleScreen';
import ActividadesScreen from './screens/ActividadesScreen';
import RegistrarActividadScreen from './screens/RegistrarActividadScreen';
import InventarioScreen from './screens/InventarioScreen';
import InsumoDetalleScreen from './screens/InsumoDetalleScreen';
import RegistrarMovimientoScreen from './screens/RegistrarMovimientoScreen';
import HistorialScreen from './screens/HistorialScreen';
import RecomendacionesScreen from './screens/RecomendacionesScreen';
import SincronizacionScreen from './screens/SincronizacionScreen';

const TAB_SCREENS: Record<NavTab, Screen> = {
  inicio: 'dashboard',
  parcelas: 'parcelas',
  inventario: 'inventario',
  actividades: 'actividades',
};

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [screen, setScreen] = useState<Screen>('dashboard');
  const [tab, setTab] = useState<NavTab>('inicio');
  const [screenStack, setScreenStack] = useState<Screen[]>([]);
  const [parcelaId, setParcelaId] = useState('p1');
  const [insumoId, setInsumoId] = useState('i1');
  const [syncStatus] = useState<SyncStatus>('pending');
  const lastSync = 'Hoy, 9:14 a.m.';

  if (!loggedIn) {
    return (
      <div className="max-w-sm mx-auto min-h-screen relative overflow-hidden">
        <LoginScreen onLogin={() => setLoggedIn(true)} />
      </div>
    );
  }

  function navigate(s: Screen) {
    setScreenStack(prev => [...prev, screen]);
    setScreen(s);
  }

  function goBack() {
    if (screenStack.length > 0) {
      const prev = screenStack[screenStack.length - 1];
      setScreenStack(p => p.slice(0, -1));
      setScreen(prev);
    }
  }

  function changeTab(t: NavTab) {
    setTab(t);
    setScreenStack([]);
    setScreen(TAB_SCREENS[t]);
  }

  const showBottomNav = !['registrar-actividad', 'registrar-movimiento', 'login'].includes(screen);

  return (
    <div className="max-w-sm mx-auto min-h-screen relative overflow-hidden bg-[#F4F6F4] flex flex-col" style={{ height: '100dvh' }}>
      <div className="flex-1 overflow-hidden relative">
        {screen === 'dashboard' && (
          <DashboardScreen
            syncStatus={syncStatus}
            lastSync={lastSync}
            onNavigate={(s) => {
              if (s === 'parcelas') changeTab('parcelas');
              else if (s === 'inventario') changeTab('inventario');
              else if (s === 'actividades') changeTab('actividades');
              else navigate(s);
            }}
          />
        )}
        {screen === 'parcelas' && (
          <ParcelasScreen
            syncStatus={syncStatus}
            onBack={() => changeTab('inicio')}
            onSelect={(id) => { setParcelaId(id); navigate('parcela-detalle'); }}
          />
        )}
        {screen === 'parcela-detalle' && (
          <ParcelaDetalleScreen
            parcelaId={parcelaId}
            syncStatus={syncStatus}
            onBack={goBack}
            onNavigate={navigate}
          />
        )}
        {screen === 'actividades' && (
          <ActividadesScreen
            syncStatus={syncStatus}
            onBack={() => changeTab('inicio')}
            onNavigate={navigate}
          />
        )}
        {screen === 'registrar-actividad' && (
          <RegistrarActividadScreen
            syncStatus={syncStatus}
            onBack={goBack}
            onSaved={goBack}
          />
        )}
        {screen === 'inventario' && (
          <InventarioScreen
            syncStatus={syncStatus}
            onBack={() => changeTab('inicio')}
            onSelect={(id) => { setInsumoId(id); navigate('insumo-detalle'); }}
            onNavigate={navigate}
          />
        )}
        {screen === 'insumo-detalle' && (
          <InsumoDetalleScreen
            insumoId={insumoId}
            syncStatus={syncStatus}
            onBack={goBack}
            onNavigate={navigate}
          />
        )}
        {screen === 'registrar-movimiento' && (
          <RegistrarMovimientoScreen
            syncStatus={syncStatus}
            onBack={goBack}
            onSaved={goBack}
          />
        )}
        {screen === 'historial' && (
          <HistorialScreen
            syncStatus={syncStatus}
            onBack={goBack}
          />
        )}
        {screen === 'recomendaciones' && (
          <RecomendacionesScreen
            syncStatus={syncStatus}
            onBack={goBack}
          />
        )}
        {screen === 'sincronizacion' && (
          <SincronizacionScreen
            syncStatus={syncStatus}
            lastSync={lastSync}
            pendingCount={2}
            errorCount={0}
            onBack={goBack}
            onRetry={() => {}}
          />
        )}
      </div>

      {showBottomNav && (
        <BottomNav active={tab} onChange={changeTab} />
      )}
    </div>
  );
}
