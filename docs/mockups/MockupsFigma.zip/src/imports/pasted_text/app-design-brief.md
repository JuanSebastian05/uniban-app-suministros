Diseña una aplicación móvil Android para gestión agrícola de productores de plátano vinculados al proyecto Unibán.

La aplicación será utilizada principalmente en campo, por lo que debe priorizar claridad, rapidez de uso, legibilidad y botones fáciles de tocar. El diseño debe sentirse moderno y profesional, pero no complejo ni futurista.

ESTILO VISUAL

Usar Material Design 3 como referencia.

Paleta visual:
- Verde oscuro como color principal.
- Verde claro para tarjetas secundarias, estados positivos y fondos suaves.
- Blanco o gris muy claro como fondo principal.
- Amarillo suave como color de acento y para elementos que requieren atención.
- Rojo únicamente para errores, pérdidas o problemas importantes.

El diseño debe tener:
- Tipografía limpia y de alta legibilidad.
- Tarjetas simples con bordes redondeados.
- Sombras muy sutiles.
- Iconos simples acompañados de texto.
- Botones grandes y claros.
- Espaciado amplio.
- Poca información por pantalla.
- Navegación inferior.
- Apariencia agrícola moderna y natural.

Evitar:
- Exceso de degradados.
- Diseños futuristas o tipo neón.
- Pantallas saturadas de gráficos.
- Tablas complejas.
- Demasiados elementos decorativos.
- Apariencia de ERP empresarial.

La aplicación debe mostrar claramente estados relacionados con operación offline, por ejemplo:
- Sincronizado.
- Sin conexión.
- 2 registros pendientes.
- Error de sincronización.
- Última sincronización: hora y fecha.

Tener conexión a internet y tener los datos sincronizados deben verse como estados diferentes.

NAVEGACIÓN PRINCIPAL

Utilizar una barra inferior con cuatro opciones:

1. Inicio
2. Parcelas
3. Inventario
4. Actividades

Las funciones secundarias como Historial, Recomendaciones y Sincronización deben abrirse desde estas pantallas y no ocupar una opción permanente en la barra principal.

Crear las siguientes pantallas:

1. LOGIN

Pantalla sencilla de acceso.

Elementos:
- Logo o identidad visual simple relacionada con agricultura.
- Correo electrónico.
- Contraseña.
- Botón “Iniciar sesión”.
- Mensajes de error claros.

No agregar registro público de usuarios.

2. INICIO / DASHBOARD

Debe funcionar como resumen general.

Mostrar:
- Saludo al usuario.
- Estado de sincronización.
- Última sincronización.
- Número de parcelas.
- Número de insumos.
- Actividades recientes.
- Inventario reciente.
- Aforamiento reciente si existe.
- Recomendaciones disponibles.
- Registros pendientes de sincronización.

Usar tarjetas visuales sencillas.

Ejemplo de resumen:

5 Parcelas
12 Insumos
8 Actividades

Mostrar accesos rápidos a:
- Ver parcelas.
- Ver inventario.
- Ver actividades.
- Historial.
- Recomendaciones.

3. PARCELAS

Mostrar un listado de parcelas pertenecientes al productor.

Cada tarjeta debe mostrar:
- Nombre de la parcela.
- Área.
- Estado o ciclo productivo actual.
- Indicador para abrir el detalle.

Ejemplo:

Parcela La Esperanza
Área: 2.4 ha
Ciclo: Activo

4. DETALLE DE PARCELA

Mostrar:

- Nombre de la parcela.
- Área.
- Ciclo productivo actual.
- Fecha de inicio del ciclo.
- Estado.

Secciones:

AFORAMIENTO
- Último aforamiento disponible.
- Fecha.
- Datos generales.

ACTIVIDADES
- Actividades recientes.
- Botón “Ver todas”.
- Botón “Registrar actividad”.

RECOMENDACIONES
- Mostrar si existen recomendaciones disponibles.
- Botón para consultarlas.

5. ACTIVIDADES

Listado de actividades productivas.

Ejemplos:
- Fertilización.
- Siembra.
- Cosecha.
- Aplicación de insumo.
- Otra actividad.

Cada elemento debe mostrar:
- Tipo.
- Parcela.
- Fecha.
- Ciclo productivo.

Incluir botón “Registrar actividad”.

6. REGISTRAR ACTIVIDAD

Formulario simple:

- Tipo de actividad.
- Parcela.
- Ciclo productivo.
- Fecha.
- Descripción.
- Botón “Guardar actividad”.

7. INVENTARIO

Esta es una de las pantallas principales.

Debe incluir:

- Barra de búsqueda.
- Filtros por categoría.
- Filtro por ubicación de inventario.
- Número total de insumos.

Cada tarjeta de inventario debe mostrar:

- Nombre del insumo.
- Categoría.
- Cantidad disponible.
- Unidad de medida.
- Ubicación de almacenamiento.

Ejemplo:

Fertilizante 15-15-15
Fertilizante
120 kg disponibles
Bodega principal

Al tocar un elemento debe abrirse el detalle del insumo.

8. DETALLE DE INSUMO

Mostrar:

- Nombre del insumo.
- Categoría.
- Unidad de medida.
- Ubicación de inventario.
- Cantidad disponible.

Mostrar también los movimientos recientes:

+ Entrada
- Salida
- Consumo
- Pérdida
± Ajuste

Incluir:

- Botón “Registrar movimiento”.
- Botón “Ver historial completo”.

9. REGISTRAR MOVIMIENTO

Esta es una pantalla crítica de la aplicación.

Formulario:

INSUMO
Selector del insumo.

TIPO DE MOVIMIENTO

Mostrar opciones visuales:

Entrada
Salida
Consumo
Pérdida
Ajuste

CANTIDAD

Campo numérico junto con la unidad de medida.

FECHA

Selector de fecha.

ACTIVIDAD ASOCIADA

Este campo debe aparecer o ser obligatorio principalmente cuando el movimiento sea de tipo “Consumo”.

Ejemplo:

Actividad asociada:
Aplicación de fertilizante
Parcela El Progreso
Ciclo actual

Para movimientos como Entrada o Ajuste, la actividad puede ser opcional.

OBSERVACIÓN

Campo de texto.

Botón principal:
“Guardar movimiento”.

Después de guardar, mostrar claramente si el movimiento quedó:

- Sincronizado.
- Pendiente de sincronización.

10. HISTORIAL / TRAZABILIDAD

Mostrar los movimientos de inventario cronológicamente.

Permitir filtros por:

- Fecha.
- Tipo de movimiento.
- Insumo.
- Parcela.

Cada registro debe mostrar:

- Tipo de movimiento.
- Insumo.
- Cantidad.
- Fecha.
- Ubicación.

Cuando corresponda también mostrar:

- Parcela.
- Ciclo.
- Actividad.

Ejemplo:

Consumo
Fertilizante 15-15-15
15 kg
Parcela La Esperanza
Actividad: Fertilización
12 abril

La pantalla debe permitir entender de dónde proviene el saldo actual del inventario.

11. RECOMENDACIONES

Pantalla para visualizar información proveniente del módulo externo de planificación.

Mostrar de forma genérica:

- Parcela.
- Ciclo.
- Periodo.
- Insumo cuando aplique.
- Cantidad recomendada.
- Observaciones.
- Alertas.

Los campos exactos aún pueden variar, por lo que el diseño debe ser flexible y basado en tarjetas.

12. ESTADO DE SINCRONIZACIÓN

Pantalla sencilla accesible desde el Dashboard.

Mostrar:

Estado actual:
Sincronizado / Sin conexión / Pendientes / Error

Última sincronización:
fecha y hora.

Registros pendientes:
cantidad.

Errores:
cantidad.

Botón:
“Reintentar sincronización”.

También mostrar un pequeño indicador de sincronización en las pantallas principales.

MODELO FUNCIONAL A REPRESENTAR VISUALMENTE

La aplicación maneja:

Productores
Parcelas
Ciclos productivos
Actividades
Insumos
Ubicaciones de inventario
Inventario
Movimientos de inventario
Aforamientos
Recomendaciones

El inventario pertenece a una ubicación de almacenamiento asociada al productor y NO directamente a una parcela.

Cuando un insumo se consume, el movimiento puede quedar asociado a una actividad, y mediante esa actividad se conoce el ciclo y la parcela donde fue utilizado.

FLUJO PRINCIPAL A DESTACAR

Login
→ Inicio
→ Inventario
→ Detalle de insumo
→ Registrar movimiento
→ Guardar localmente
→ Mostrar estado pendiente o sincronizado
→ Inventario actualizado.

Otro flujo importante:

Inicio
→ Parcelas
→ Detalle de parcela
→ Actividades
→ Registrar actividad.

Crear todas las pantallas con una identidad visual consistente entre sí, manteniendo navegación, colores, tarjetas, botones e indicadores de sincronización con el mismo lenguaje visual.